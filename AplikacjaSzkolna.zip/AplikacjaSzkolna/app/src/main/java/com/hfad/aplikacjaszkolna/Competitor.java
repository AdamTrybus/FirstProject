package com.hfad.aplikacjaszkolna;

public class Competitor {
    String uczestnik;

    public Competitor() {
    }

    public Competitor(String uczestnik) {
        this.uczestnik = uczestnik;
    }
}
