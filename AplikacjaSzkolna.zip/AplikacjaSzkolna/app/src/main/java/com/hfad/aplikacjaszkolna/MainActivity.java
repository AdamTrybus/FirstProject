package com.hfad.aplikacjaszkolna;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

    }
    public void onClickCategory(View view) {
        Intent intent = new Intent(this, CategoryActivity.class);
        switch (view.getId()){
            case R.id.walory_muz:
                intent.putExtra("WALORY","MUZ");
                break;
            case R.id.walory_jez:
                intent.putExtra("WALORY","JEZ");
                break;
        }
        startActivity(intent);
    }

    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_send_all,menu);
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.action_send_all:
                try {
                    Intent intent = new Intent(Intent.ACTION_SEND);
                    intent.setType("text/plain");
                    intent.putExtra(Intent.EXTRA_SUBJECT, "JOSE SONG - Wyniki");
                    //intent.putExtra(Intent.EXTRA_STREAM, writeFile());
                    String chooserTitle = getString(R.string.chooser_title);
                    Intent chosenIntent = Intent.createChooser(intent,chooserTitle);
                    startActivity(chosenIntent);
                }catch (SQLException e){
                    Toast toast = Toast.makeText(this, "Baza danych jest niedostępna", Toast.LENGTH_SHORT);
                    toast.show();
                }
                return true;
                default:
                    return super.onOptionsItemSelected(item);
        }
    }


    /*private Uri writeFile(){
        StringBuilder sb = new StringBuilder();
        SQLiteOpenHelper appDatabaseHelper = new DatabaseHelper(this);
        db = appDatabaseHelper.getReadableDatabase();
        cursor = db.query("APP",
                new String[]{"NAME","POINTS"},
                "POINTS > ?", new String[]{Integer.toString(0)}, null, null, null);
        sb.append("NAME,POINTS\n");
        if(cursor.moveToFirst()){
            sb.append(cursor.getString(0)+ "," + cursor.getInt(1) + "\n");
        }
        while(cursor.moveToNext()){
            sb.append(cursor.getString(0)+ "," + cursor.getInt(1) + "\n");
        }

        File file = null;
//        File root = Environment.getExternalStorageDirectory();
        File root = getApplicationContext().getExternalFilesDir(null);
        if (root.canWrite()){
            File dir = new File (root.getAbsolutePath() + "/PersonData");
            dir.mkdirs();
            file = new File(dir, "Data.csv");
            FileOutputStream out   =   null;
            try {
                out = new FileOutputStream(file);
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
            try {
                out.write(sb.toString().getBytes());
            } catch (IOException e) {
                e.printStackTrace();
            }
            try {
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        Uri fileUri = Uri.fromFile(file);
        return fileUri;
    }*/
}
