package com.hfad.aplikacjaszkolna;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteException;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class DetailsJezActivity extends AppCompatActivity {
    public static final String EXTRA_NAME_ID = "nameId";
    private String name ;
    private int points;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details_jez);

        int nameId = (Integer)getIntent().getExtras().get(EXTRA_NAME_ID);
    }
    public boolean onCreateOptionsMenu(Menu menu){
        getMenuInflater().inflate(R.menu.menu_save,menu);
        return super.onCreateOptionsMenu(menu);
    }
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);
        Spinner spinner1 = (Spinner) findViewById(R.id.mark_wymowa);
        Spinner spinner2 = (Spinner) findViewById(R.id.mark_pop_jez);
        Spinner spinner3 = (Spinner) findViewById(R.id.mark_znaj_tekstu);
        Spinner spinner4 = (Spinner) findViewById(R.id.mark_dykcja);
        switch (item.getItemId()) {
            case R.id.action_save:
                int punkty1 = Integer.valueOf(spinner1.getSelectedItem().toString());
                int punkty2 = Integer.valueOf(spinner2.getSelectedItem().toString());
                int punkty3 = Integer.valueOf(spinner3.getSelectedItem().toString());
                int punkty4 = Integer.valueOf(spinner4.getSelectedItem().toString());
                points = punkty1 + punkty2 + punkty3 + punkty4;

                int nameId = (Integer)getIntent().getExtras().get(EXTRA_NAME_ID);

                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
