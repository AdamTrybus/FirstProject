package com.hfad.aplikacjaszkolna;

import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class CategoryActivity extends AppCompatActivity {

    private DatabaseReference mDatabase;
    private String[] uczestnicy;
    private int i =0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_category);
        ListView listSingers = (ListView) findViewById(R.id.list_singers);
        mDatabase = FirebaseDatabase.getInstance().getReference().child("competitors");
        mDatabase.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                uczestnicy = new String[(int) dataSnapshot.getChildrenCount()];
                Competitor competitor = dataSnapshot.getValue(Competitor.class);
                uczestnicy[i] = competitor.uczestnik;
                i++;
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        ArrayAdapter adapter = new ArrayAdapter(this,android.R.layout.simple_list_item_1,uczestnicy);
        listSingers.setAdapter(adapter);

        // Tworzymy obiekt nasłuchujący zdarzeń kliknięć elementów listy
        AdapterView.OnItemClickListener itemClickListener = new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(CategoryActivity.this, DetailsJezActivity.class);
                intent.putExtra(DetailsMuzActivity.EXTRA_NAME_ID ,(int) id);
                startActivity(intent);
            }
        };
        listSingers.setOnItemClickListener(itemClickListener);
    }

}
