package com.sample.notify;

import android.annotation.TargetApi;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CalendarView;
import android.widget.ImageView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.shrikanthravi.collapsiblecalendarview.widget.CollapsibleCalendar;

import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;

import io.opencensus.resource.Resource;

public class NotificationActivity extends AppCompatActivity{

    public static final String PRZEDMIOT = "PRZEDMIOT";
    public static final String POZIOM = "POZIOM";
    public static final String CZAS = "CZAS";
    public static final String LATITUDE = "LATITUDE";
    public static final String LONGITUDE = "LONGITUDE";

    final private String FCM_API = "https://fcm.googleapis.com/fcm/send";
    final private String serverKey = "key=" + "AAAANx6k1Ps:APA91bEfZVfyyDKH3WInPrpxro_7u_fvbUD5S5bZbisQqYiblVT3YJsL58R2fxCTXn1yh61fE_hNbEsVr53A5HBbm-aPTFvMymzMZF1BvGrc_6KAXXxTfKpZsUry9PYCtNhe4WXMTesl ";
    final private String contentType = "application/json";
    final String TAG = "NOTIFICATION TAG";

    
    String NOTIFICATION_TITLE;
    String NOTIFICATION_MESSAGE;
    String TOPIC;
    Intent intent;
    private StringBuilder dzien ;
    private StringBuilder godzina ;
    private FloatingActionButton fab;
    TimePicker timePicker1;
    TimePicker timePicker2;
    FirebaseUser user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);
        setContentView(R.layout.activity_notification);
        Button btnAccept = findViewById(R.id.btnAccept);
        user = FirebaseAuth.getInstance().getCurrentUser();
        intent = getIntent();
        dzien = new StringBuilder();
        godzina = new StringBuilder();
        getSupportActionBar().setElevation(0);
        CollapsibleCalendar collapsibleCalendar = findViewById(R.id.collapsibleCalendarView);
        Calendar today=new GregorianCalendar();

        System.out.println("Testing date "+collapsibleCalendar.getSelectedDay().getDay()+"/"+collapsibleCalendar.getSelectedDay().getMonth()+"/"+collapsibleCalendar.getSelectedDay().getYear());
        collapsibleCalendar.setCalendarListener(new CollapsibleCalendar.CalendarListener() {
            @Override
            public void onDaySelect() {

            }

            @Override
            public void onItemClick(View v) {

            }

            @Override
            public void onDataUpdate() {

            }

            @Override
            public void onMonthChange() {

            }

            @Override
            public void onWeekChange(int position) {

            }
        });
        fab = findViewById(R.id.fab);
        timePickers();
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(fab.getBackgroundTintList() == ColorStateList.valueOf(getApplication().getResources().getColor(R.color.red))){
                    Toast.makeText(getApplicationContext(),"Nieprawidłowy przedział godzin",Toast.LENGTH_SHORT).show();
                }
                else{
                    String d = collapsibleCalendar.getSelectedDay().getDay() + "/" + collapsibleCalendar.getSelectedDay().getMonth() + "/" + collapsibleCalendar.getSelectedDay().getYear() + ",";
                    String g = timePicker1.getCurrentHour()+" - "+timePicker2.getCurrentHour()+ ",";
                    dzien.append(d);
                    godzina.append(g);
                   /*Snackbar.make(findViewById(R.id.relLayout),"Dodano do twojego terminarza",Snackbar.LENGTH_SHORT).setAction("Cofnij", new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dzien.setLength(dzien.length()-d.length());
                            godzina.setLength(godzina.length() - g.length());
                            Toast.makeText(getApplicationContext(),"Cofnięto!",Toast.LENGTH_SHORT).show();
                        }
                    });*/
                }
            }
        });

        btnAccept.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TOPIC = "/topics/userABC"; //topic has to match what the receiver subscribed to
                NOTIFICATION_TITLE = "WorkForAll";
                NOTIFICATION_MESSAGE = "Zobacz szczegóły oferty";
                //FirebaseMessaging.getInstance().unsubscribeFromTopic(SUBSCRIBE_TO);

                JSONObject notification = new JSONObject();
                JSONObject notifcationBody = new JSONObject();

                try {
                    notifcationBody.put("title", NOTIFICATION_TITLE);
                    notifcationBody.put("message", NOTIFICATION_MESSAGE);
                    notifcationBody.put("token", FirebaseInstanceId.getInstance().getToken());
                    notifcationBody.put("przedmiot",intent.getStringExtra(PRZEDMIOT));
                    notifcationBody.put("poziom",intent.getStringExtra(POZIOM));
                    notifcationBody.put("czas",intent.getStringExtra(CZAS));
                    notifcationBody.put("latitude",intent.getStringExtra(LATITUDE));
                    notifcationBody.put("longitude",intent.getStringExtra(LONGITUDE));
                    notifcationBody.put("dzien",dzien);
                    notifcationBody.put("godzina",godzina);
                    notifcationBody.put("name","zero");
                    notifcationBody.put("uczen",user.getPhoneNumber());

                    notification.put("to", TOPIC);
                    notification.put("data", notifcationBody);

                } catch (JSONException e) {
                    Log.e(TAG, "onCreate: " + e.getMessage() );
                }
                sendNotification(notification);
                FirebaseMessaging.getInstance().subscribeToTopic(TOPIC);
                Intent intent1 = new Intent(NotificationActivity.this,MainActivity.class);
                Toast toast = Toast.makeText(getApplicationContext(),"Prosze czekac na odpowiedź korepetytora",Toast.LENGTH_SHORT);
                startActivity(intent1);
                toast.show();
            }
        });

    }

    private void sendNotification(JSONObject notification) {
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(FCM_API, notification,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i(TAG, "onResponse: " + response.toString());
                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(NotificationActivity.this, "Request error", Toast.LENGTH_LONG).show();
                        Log.i(TAG, "onErrorResponse: Didn't work");
                    }
                }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("Authorization", serverKey);
                params.put("Content-Type", contentType);
                return params;
            }
        };
        MySingleton.getInstance(getApplicationContext()).addToRequestQueue(jsonObjectRequest);
    }
    private void timePickers(){
        timePicker1 = findViewById(R.id.timePicker1);
        timePicker2 = findViewById(R.id.timePicker2);
        timePicker1.setIs24HourView(true);
        timePicker2.setIs24HourView(true);
        timePicker2.setCurrentHour(20);
        timePicker1.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                if(hourOfDay>=timePicker2.getCurrentHour()){
                    fab.setBackgroundTintList(ColorStateList.valueOf(getApplication().getResources().getColor(R.color.red)));
                }
                else {
                    fab.setBackgroundTintList(ColorStateList.valueOf(getApplication().getResources().getColor(R.color.green)));
                }
            }
        });
        timePicker2.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                if(hourOfDay<=timePicker1.getCurrentHour()){
                    fab.setBackgroundTintList(ColorStateList.valueOf(getApplication().getResources().getColor(R.color.red)));
                }
                else {
                    fab.setBackgroundTintList(ColorStateList.valueOf(getApplication().getResources().getColor(R.color.green)));
                }
            }
        });
    }
}

