package com.sample.notify;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import com.google.android.material.navigation.NavigationView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{

    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        FirebaseApp.initializeApp(this);
        setContentView(R.layout.activity_main);

        user = FirebaseAuth.getInstance().getCurrentUser();
        user = null;
        if(user==null){
            startActivity(new Intent(this, SignupActivity.class));
            finish();
            return;
        }
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this,drawer,toolbar,R.string.nav_open,R.string.nav_close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();
        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);
    }

    public void onClickDetails(View view) {
        Spinner poziom = (Spinner) findViewById(R.id.spinner_poziom);
        Spinner przedmiot = (Spinner) findViewById(R.id.spinner_przedmiot);
        Spinner czas = (Spinner) findViewById(R.id.spinner_czas);

        Intent intent = new Intent(this, MapActivity.class);
        intent.putExtra(MapActivity.POZIOM,poziom.getSelectedItem().toString());
        intent.putExtra(MapActivity.PRZEDMIOT,przedmiot.getSelectedItem().toString());
        intent.putExtra(MapActivity.CZAS,czas.getSelectedItem().toString());
        startActivity(intent);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        Intent intent1 = null;
        switch (item.getItemId()){
            case R.id.lekcje:
                intent1 = new Intent(MainActivity.this, LessonsActivity.class);
                break;
        }
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        startActivity(intent1);
        drawer.closeDrawer(GravityCompat.START);
        return true;
    }
}
