package com.sample.notify;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.TextView;

public class SecondNotifyActivity extends AppCompatActivity {

    public static final String TOKEN ="cosjeszcze_jeszczeinnego";
    public static final String DAY = "DAY";
    public static final String HOUR = "HOUR";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second_notify);
        final Intent intent = getIntent();
        TextView textViewWhen = (TextView)findViewById(R.id.textViewWhen);
        textViewWhen.setText(intent.getStringExtra(DAY) + " - " + intent.getStringExtra(HOUR));
    }
}
