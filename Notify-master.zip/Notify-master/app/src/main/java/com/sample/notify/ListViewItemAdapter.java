package com.sample.notify;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class ListViewItemAdapter extends BaseAdapter {

    private LayoutInflater mInflater;
    private String[] date;
    private String[] hour;

    public ListViewItemAdapter(Context c, String[] data1, String[] hour1){
        date = data1;
        hour = hour1;
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }
    @Override
    public int getCount() {
        return date.length;
    }

    @Override
    public Object getItem(int position) {
        return date[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = mInflater.inflate(R.layout.listview_details, null);
        TextView txtData = v.findViewById(R.id.data);
        TextView txtHour = v.findViewById(R.id.hour);
        txtData.setText(date[position]);
        txtHour.setText(hour[position]);
        return v;
    }
}
