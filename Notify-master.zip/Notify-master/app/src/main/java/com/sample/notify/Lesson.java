package com.sample.notify;

public class Lesson {

    public String poziom;
    public String przedmiot;
    public String czas;
    public String day;
    public String hour;
    public String latitude;
    public String longitude;
    public String token;
    public String uczen;
    public String korepetytor;

    public Lesson() {
    }

    public Lesson(String poziom, String przedmiot, String czas, String day, String hour, String latitude, String longitude, String token, String uczen,String korepetytor) {
        this.poziom = poziom;
        this.przedmiot = przedmiot;
        this.czas = czas;
        this.day = day;
        this.hour = hour;
        this.latitude = latitude;
        this.longitude = longitude;
        this.token = token;
        this.uczen = uczen;
        this.korepetytor = korepetytor;
    }
}
