package com.sample.notify;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

public class TimeAdapter extends RecyclerView.Adapter<TimeAdapter.MyViewHolder> {

    String[] slot;
    Context context;
    private Listener listener;
    interface Listener {
        void onClick(int position);
    }

    public TimeAdapter(Context context, String[] slot) {
        this.slot = slot;
        this.context = context;
    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int i) {
        CardView cv = (CardView) LayoutInflater.from(parent.getContext())
                .inflate(R.layout.card_slot_time, parent, false);
        return new MyViewHolder(cv);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder myViewHolder, int i) {
        final CardView cardView = myViewHolder.cardView;
        final TextView txt_time_slot = cardView.findViewById(R.id.txt_time_slot);
        txt_time_slot.setText(slot[i]);
        cardView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v) {
                myViewHolder.cardView.setCardBackgroundColor(context.getResources().getColor(android.R.color.holo_green_light));
            }
        });
    }

    @Override
    public int getItemCount() {
        return slot.length;
    }
    public void setListener(Listener listener){
        this.listener = listener;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        private CardView cardView;

        public MyViewHolder(@NonNull CardView itemView) {
            super(itemView);
            cardView = itemView;
        }
    }
}
