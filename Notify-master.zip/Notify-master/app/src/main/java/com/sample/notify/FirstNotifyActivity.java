package com.sample.notify;

import android.app.Dialog;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class FirstNotifyActivity extends AppCompatActivity implements OnMapReadyCallback {

    public static final String PRZEDMIOT = "PRZEDMIOT";
    public static final String POZIOM = "POZIOM";
    public static final String LATITUDE = "LATITUDE";
    public static final String LONGITUDE = "LONGITUDE";
    public static final String CZAS = "CZAS";
    public static final String TOKEN ="cosjeszczeinnego";
    public static final String DZIEN ="DZIEN";
    public static final String GODZINA ="GODZINA";
    public static final String UCZEN ="UCZEN";

    final private String FCM_API = "https://fcm.googleapis.com/fcm/send";
    final private String serverKey = "key=" + "AAAANx6k1Ps:APA91bEfZVfyyDKH3WInPrpxro_7u_fvbUD5S5bZbisQqYiblVT3YJsL58R2fxCTXn1yh61fE_hNbEsVr53A5HBbm-aPTFvMymzMZF1BvGrc_6KAXXxTfKpZsUry9PYCtNhe4WXMTesl ";
    final private String contentType = "application/json";
    final String TAG = "NOTIFICATION TAG";
    private Dialog dialog;
    private ListViewItemAdapter itemAdapter;
    private String[] day;
    private String[] hour;
    private Intent intent;
    private int id;
    private DatabaseReference database;
    FirebaseAuth firebaseAuth;
    FirebaseUser user;
    long childNumber;
    GoogleMap map;
    SupportMapFragment mapFragment;
    FusedLocationProviderClient fusedLocationProviderClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_notify);
        dialog = new Dialog(this);
        firebaseAuth = FirebaseAuth.getInstance();

        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);
        mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.mapSHows);
        mapFragment.getMapAsync(this);

        intent = getIntent();

        TextView textViewName = (TextView) findViewById(R.id.textViewPoziom);
        textViewName.setText(intent.getStringExtra(POZIOM));
        TextView textViewText = (TextView) findViewById(R.id.textViewPrzedmiot);
        textViewText.setText(intent.getStringExtra(PRZEDMIOT));
        TextView textViewCzas = (TextView) findViewById(R.id.textViewCzas);
        textViewCzas.setText(intent.getStringExtra(CZAS));

        day =  intent.getStringExtra(DZIEN).split(",");
        hour =  intent.getStringExtra(GODZINA).split(",");

        itemAdapter = new ListViewItemAdapter(this,day,hour);
        Button btnResend = (Button) findViewById(R.id.btnReAccept);
        btnResend.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View v) {
                dialog.setContentView(R.layout.choose_data_popup_window);
                Button btnOK2 = (Button) dialog.findViewById(R.id.btnOK2);
                btnOK2.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        onSureSendNotify(intent);
                        Intent intent1 = new Intent(FirstNotifyActivity.this,MainActivity.class);
                        startActivity(intent1);
                        dialog.dismiss();
                    }
                });
                final ListView listView = (ListView) dialog.findViewById(R.id.listViewDetail);
                listView.setAdapter(itemAdapter);
                listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                    @Override
                    public void onItemClick(AdapterView<?> parent, View view, int position,long arg3) {
                        id = position;
                    }
                });
                dialog.show();
            }
        });
    }
    private void sendNotification(JSONObject notification) {
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(FCM_API, notification,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {
                        Log.i(TAG, "onResponse: " + response.toString());

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        Toast.makeText(FirstNotifyActivity.this, "Request error", Toast.LENGTH_LONG).show();
                        Log.i(TAG, "onErrorResponse: Didn't work");
                    }
                }){
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("Authorization", serverKey);
                params.put("Content-Type", contentType);
                return params;
            }
        };
        MySingleton.getInstance(getApplicationContext()).addToRequestQueue(jsonObjectRequest);
    }
    private void onSureSendNotify(Intent intent){
        String NOTIFICATION_TITLE = "WorkForAll";
        String NOTIFICATION_MESSAGE = "Zobacz szczegóły oferty";

        JSONObject notification = new JSONObject();
        JSONObject notifcationBody = new JSONObject();
        try {
            notifcationBody.put("title", NOTIFICATION_TITLE);
            notifcationBody.put("message", NOTIFICATION_MESSAGE);
            notifcationBody.put("name1","zero");

            notification.put("to", intent.getStringExtra(TOKEN));
            notification.put("data", notifcationBody);

        } catch (JSONException e) {
            Log.e(TAG, "onCreate: " + e.getMessage() );
        }
        sendNotification(notification);
        saveData();
        Intent intent1 = new Intent(FirstNotifyActivity.this,MainActivity.class);
        startActivity(intent1);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        map = googleMap;
        getPlace();
    }
    private void getPlace(){
        if (map == null) {
            return;
        }
        Double latitude = Double.parseDouble(intent.getStringExtra(LATITUDE));
        Double longitude = Double.parseDouble(intent.getStringExtra(LONGITUDE));
        LatLng latLng = new LatLng(latitude,longitude);
        String adres = "";
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
            adres = addresses.get(0).getAddressLine(0);
        } catch (IOException e) {
            e.printStackTrace();
        }
        MarkerOptions markerOptions = new MarkerOptions().position(latLng).title(adres);
        map.clear();
        map.addMarker(markerOptions);
        map.animateCamera(CameraUpdateFactory.newLatLngZoom(latLng, 15));
    }
    private void saveData(){
        user = firebaseAuth.getCurrentUser();
        database =  FirebaseDatabase.getInstance().getReference().child("lessons");
        database.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                if (dataSnapshot.exists()){
                    childNumber = dataSnapshot.getChildrenCount();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });
        Lesson lesson = new Lesson(intent.getStringExtra(POZIOM),intent.getStringExtra(PRZEDMIOT),
                intent.getStringExtra(CZAS),day[id],hour[id],intent.getStringExtra(LATITUDE),intent.getStringExtra(LONGITUDE),
                FirebaseInstanceId.getInstance().getToken(),intent.getStringExtra(UCZEN),user.getPhoneNumber());
        database.child(String.valueOf(childNumber + 1)).setValue(lesson);
    }
}
