package com.sample.notify;

import android.content.Context;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;

public class LessonsItemAdapter extends BaseAdapter {
    private LayoutInflater mInflater;
    private String[] miejsce;
    private String[] data;
    private String[] name;
    private Context c1;

    public LessonsItemAdapter(Context c, String[] miejsce1, String[] data1,String[] name1){
        mInflater = (LayoutInflater) c.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        miejsce = miejsce1;
        data = data1;
        name = name1;
        c1 = c;
    }
    @Override
    public int getCount() {
        return miejsce.length;
    }
    @Override
    public Object getItem(int position) {
        return miejsce[position];
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {
        View v = mInflater.inflate(R.layout.lessons_details, null);
        TextView txtMiejsce = v.findViewById(R.id.txtVMiejsce);
        txtMiejsce.setText(miejsce[position]);
        TextView txtData = v.findViewById(R.id.txtVData);
        txtData.setText(data[position]);
        TextView txtName = v.findViewById(R.id.txtVName);
        txtName.setText(name[position]);
        return v;
    }
}
