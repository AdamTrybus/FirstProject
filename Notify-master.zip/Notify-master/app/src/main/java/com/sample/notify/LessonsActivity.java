package com.sample.notify;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.location.Address;
import android.location.Geocoder;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;
import com.google.firebase.FirebaseError;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.stream.Collectors;

import static java.util.stream.Collectors.toList;

public class LessonsActivity extends AppCompatActivity {


    private LessonsItemAdapter itemAdapter;
    private String[] miejsce;
    private String[] data;
    private String[] name;
    private int i;
    private DatabaseReference database;
    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lessons);
        user = FirebaseAuth.getInstance().getCurrentUser();
        database = FirebaseDatabase.getInstance().getReference().child("lessons");
        readData();
    }

    private void readData() {
        Query searchQuery = database.orderByChild("uczen").equalTo(user.getPhoneNumber());
        searchQuery.addValueEventListener(queryValueEventListener);
    }

    ValueEventListener queryValueEventListener = new ValueEventListener() {
        @Override
        public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
            i = (int) dataSnapshot.getChildrenCount();
            miejsce = new String[i];
            name = new String[i];
            data = new String[i];
            i=0;
            for (DataSnapshot singleSnapshot: dataSnapshot.getChildren()){
                Lesson lesson = singleSnapshot.getValue(Lesson.class);
                miejsce[i]=getAddress(lesson.latitude,lesson.longitude);
                data[i]=lesson.day+" - "+lesson.hour;
                name[i]=lesson.korepetytor;
                i++;
            }
           showList();
        }

        @Override
        public void onCancelled(@NonNull DatabaseError databaseError) {

        }
    };
    private void showList(){
        final ListView listView = (ListView) findViewById(R.id.listVLesson);
        itemAdapter = new LessonsItemAdapter(this,miejsce,data,name);
        if(miejsce.length!=0) {
            listView.setAdapter(itemAdapter);
            listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                }
            });
        }
    }
    private String getAddress(String lat1,String lng1){
        Double lat = Double.parseDouble(lat1);
        Double lng = Double.parseDouble(lng1);
        String adres = "";
        Geocoder geocoder = new Geocoder(this, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1); // Here 1 represent max location result to returned, by documents it recommended 1 to 5
            adres = addresses.get(0).getAddressLine(0);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return adres;
    }
}


